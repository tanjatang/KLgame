from .BaseAgent import BaseAgent
from .FinnAgentO import FinnAgent
from environment.game import Game
from environment.models.game_object import GameObject
from environment.models.position import Position
from environment.models.snake import Snake
from environment.models.constants import Direction, ALL_DIRECTIONS, DirectionUtil
from environment.models.grid_map import GridMap
import math
from util.kl_priority_queue import KLPriorityQueue
from typing import List, Tuple, Optional
import numpy


# def get_G(child: Position,current:Position)-> int:
#     G = 0
#
#     came_from = {child: current}
#     while came_from.get(child) is not None:
#         G += 1
#         child = current
#     return G


class KILabAgent(BaseAgent):

    def act(self, game: Game, snake_idx: int)-> Optional[Direction]:
        print("act")
        print("//////////////////////////////////////////////////////////////////////////////////////")
        snake = game.get_snake(snake_idx)
        grid_map = game.get_grid()
        head = snake.get_head()
        fruits = game.get_fruits()
        for fruit in fruits:
            distance, path = a_star_search(head, head.direction, fruit, grid_map)
            direction = self.calculation_direction(path,game,snake_idx)
        return direction

    # def calculation_direction(self,Path_List:List)->Direction:
    #     if len(Path_List) > 2:
    #         # for i in range(len(Path_List)-1):
    #         first=Path_List[i]
    #         second=Path_List[i+1]
    #         if second.x < first.x:
    #             return Direction.LEFT
    #         elif second.x>first.x:
    #             return Direction.RIGHT
    #         elif second.y<first.y:
    #             return Direction.UP
    #         elif second.y>first.y:
    #             return Direction.DOWN
    #     elif len(Path_List) == 1:
    #         return None
    #     elif len(Path_List)<1:
    #         return None
    def calculation_direction(self,Path_List:List,game: Game, snake_idx: int) ->Direction:
        snake = game.get_snake(snake_idx)
        head=snake.get_head()
        if len(Path_List)>1:
            # start = Path_List.pop()
            first_next=Path_List.pop()
            best_child=Path_List.pop()
            if best_child.x<first_next.x:
                return Direction.LEFT
            elif best_child.x>first_next.x:
                return Direction.RIGHT
            elif best_child.y<first_next.y:
                return Direction.UP
            elif best_child.y>first_next.y:
                return Direction.DOWN
        elif len(Path_List)==1:
            return head.direction
        elif len(Path_List)<1:
            return None


    # def calculation_next_position(self):
    #     pass
    # def min_child_caculation(self,F_children):
    #     print(str(min(F_children))+"kkkkklmmmmmmmmmmmm")
    #     return min(F_children)

    def get_name(self, snake_idx: int):
        return 'A*SNAKE (TANG)'

    @classmethod
    def get_heuristic(cls, start_field:Position, search_field:Position)->float:
        h = math.sqrt(numpy.square(start_field.x - search_field.x) + numpy.square(start_field.y - search_field.y))
        return h


'''nur ein path fur child.berechen die best path'''
def a_star_search(start_field: Position,
                  start_direction: Direction,
                  search_field: Position,
                  grid_map: GridMap)-> Tuple[int, List[any]]:
    # K=KILabAgent()
    queue = KLPriorityQueue()
    came_from = {}
    cost_so_far = {}
    # Initialisierung

    h0 = KILabAgent.get_heuristic(start_field, search_field)

    # h0 = 0
    G = 0
    F0 = h0 + G
    came_from[start_field] = None
    cost_so_far[start_field] = G
    first_next = grid_map.get_neighbor(start_field.x, start_field.y, start_direction)  # 第一个移动后的位置，
    came_from[first_next] = start_field
    # queue.put(F0, start_field) #等待explor的field
    queue.put(0,first_next)# in order to set the first_next which corresponds to start_direction as first pop
    queue.put(1000, start_field)
    G +=1
    h_first_next=KILabAgent.get_heuristic(first_next,search_field)
    F1=h_first_next+G
    cost_so_far[first_next] = G
    # path = [start_field,first_next]
    # path = [start_field]
    cost = [F0,F1]
    # cost =[F0]
    # Schleife
    while not queue.empty():
        current = queue.get()
        if current == search_field:

            print("search finish")
            break
        neighbours = grid_map.get_neighbors(current.x, current.y)
        F_list = []
        for child in neighbours:
            G_child = cost_so_far[current] + 1 # compute G for child
            if Game.is_obstacle(child) or child in came_from:
                break
            else:
                h_child = KILabAgent.get_heuristic(child, search_field)
                F_child= h_child + G_child
                cost_so_far[child] = G_child
                queue.put(F_child,child)
                # print(str(queue.get_size()) + "queue")
                came_from[child] = current
                cost.append(F_child)

    leaf = search_field
    path = [leaf]
    while leaf != start_field:
        if leaf not in came_from:
            print("cannot find goal")
            break
        else:
            leaf = came_from[leaf]
            path.append(leaf)
            print("it will be succesfull")
    path.reverse()
    path.pop()
    return cost, path



